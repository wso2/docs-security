#!/bin/bash

# Create temp directory for process jar file.
mkdir $SCRIPT/temp

# Move org.wso2.carbon.identity.mgt jar file to current folder
mv $CARBON_HOME/repository/components/plugins/org.wso2.carbon.identity.mgt_*.jar .

JAR_FILE=$(ls org.wso2.carbon.identity.mgt_*.jar 2>/dev/null)

# Extract the part of the filename after the underscore
version_part=$(echo "$JAR_FILE" | awk -F'_' '{print $2}')

# Extract the version number before the '.jar'
VERSION_NUMBER=$(echo "$version_part" | awk -F'.jar' '{print $1}')

# Unzip the jar into the temp folder
unzip -q "org.wso2.carbon.identity.mgt_*.jar" -d "$SCRIPT/temp"

# Define the path to the XML file
FILE_PATH="$SCRIPT/temp/META-INF/services.xml"

# Define the old and new values
OLD_VALUE='<parameter name="AuthorizationAction" locked="true">/permission/admin/login</parameter>'
NEW_VALUE='<parameter name="AuthorizationAction" locked="true">/permission/admin</parameter>'

# Use sed to replace the old value with the new value

sed -i.bak "s|$OLD_VALUE|$NEW_VALUE|" $FILE_PATH

# Remove the bakcup file.
rm -f $FILE_PATH.bak

cd ../temp
zip -r org.wso2.carbon.identity.mgt_$VERSION_NUMBER.jar .

mv org.wso2.carbon.identity.mgt_$VERSION_NUMBER.jar $CARBON_HOME/repository/components/plugins

# Clean the temp folder
rm -rf "$SCRIPT/temp"

# Remove the copied jar.
rm -f "$SCRIPT/start/org.wso2.carbon.identity.mgt_$VERSION_NUMBER.jar"


echo "Update completed."
